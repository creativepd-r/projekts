import sqlite3
from pathlib import Path

from flask import Flask, abort, flash, redirect, render_template, request, url_for

# Datubāzes fails atradīsies tajā pašā mapē, kur app.py
DB_PATH = Path(__file__).parent / "tennis_stats.db"

app = Flask(__name__)
app.config["SECRET_KEY"] = "tennis-stats-secret-key"


def get_db():
    """Atver savienojumu ar jau izveidotu SQLite datubāzi."""
    if not DB_PATH.exists():
        raise FileNotFoundError(
            "Nav atrasts tennis_stats.db fails. Datubāzei jāatrodas tajā pašā mapē, kur app.py."
        )

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def to_int(value, default=0):
    """Pārveido teksta vērtību par skaitli. Tukšu lauku aizstāj ar default."""
    value = (value or "").strip()
    try:
        return int(value) if value else default
    except ValueError:
        return default


def get_players_and_tournaments():
    """Palīgfunkcija formām, kur vajag spēlētāju un turnīru sarakstus."""
    conn = get_db()
    players = conn.execute(
        "SELECT id, first_name, last_name FROM players ORDER BY last_name, first_name"
    ).fetchall()
    tournaments = conn.execute(
        "SELECT id, name, surface FROM tournaments ORDER BY name"
    ).fetchall()
    conn.close()
    return players, tournaments


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/database")
def database_info():
    conn = get_db()
    tables = []
    for table_name in ["players", "tournaments", "matches", "match_stats"]:
        columns = conn.execute(f"PRAGMA table_info({table_name})").fetchall()
        count = conn.execute(f"SELECT COUNT(*) AS total FROM {table_name}").fetchone()["total"]
        tables.append({"name": table_name, "columns": columns, "count": count})
    conn.close()
    return render_template("database.html", tables=tables)


# ---------- Spēlētāji ----------

@app.route("/players")
def players_list():
    conn = get_db()
    players = conn.execute(
        """
        SELECT id, first_name, last_name, country, birth_year, hand
        FROM players
        ORDER BY last_name, first_name
        """
    ).fetchall()
    conn.close()
    return render_template("players/list.html", players=players)


@app.route("/players/new")
def players_new():
    return render_template("players/new.html")


@app.route("/players", methods=["POST"])
def players_create():
    first_name = request.form.get("first_name", "").strip()
    last_name = request.form.get("last_name", "").strip()
    country = request.form.get("country", "").strip() or None
    birth_year = to_int(request.form.get("birth_year"), None)
    hand = request.form.get("hand", "").strip().upper() or None

    if not first_name or not last_name:
        flash("Vārds un uzvārds ir obligāti.", "error")
        return render_template("players/new.html", form=request.form)

    conn = get_db()
    conn.execute(
        """
        INSERT INTO players (first_name, last_name, country, birth_year, hand)
        VALUES (?, ?, ?, ?, ?)
        """,
        (first_name, last_name, country, birth_year, hand),
    )
    conn.commit()
    conn.close()
    flash("Spēlētājs pievienots.", "success")
    return redirect(url_for("players_list"))


@app.route("/players/<int:player_id>")
def players_view(player_id):
    conn = get_db()
    player = conn.execute("SELECT * FROM players WHERE id = ?", (player_id,)).fetchone()
    if player is None:
        conn.close()
        abort(404)

    matches = conn.execute(
        """
        SELECT m.id, m.match_date, m.round, m.score, t.name AS tournament_name,
               wp.first_name AS winner_first, wp.last_name AS winner_last,
               lp.first_name AS loser_first, lp.last_name AS loser_last
        FROM matches m
        JOIN tournaments t ON t.id = m.tournament_id
        JOIN players wp ON wp.id = m.winner_player_id
        JOIN players lp ON lp.id = m.loser_player_id
        WHERE m.winner_player_id = ? OR m.loser_player_id = ?
        ORDER BY m.match_date DESC
        """,
        (player_id, player_id),
    ).fetchall()
    conn.close()
    return render_template("players/view.html", player=player, matches=matches)


@app.route("/players/<int:player_id>/edit")
def players_edit(player_id):
    conn = get_db()
    player = conn.execute("SELECT * FROM players WHERE id = ?", (player_id,)).fetchone()
    conn.close()
    if player is None:
        abort(404)
    return render_template("players/edit.html", player=player)


@app.route("/players/<int:player_id>", methods=["POST"])
def players_update(player_id):
    first_name = request.form.get("first_name", "").strip()
    last_name = request.form.get("last_name", "").strip()
    country = request.form.get("country", "").strip() or None
    birth_year = to_int(request.form.get("birth_year"), None)
    hand = request.form.get("hand", "").strip().upper() or None

    if not first_name or not last_name:
        flash("Vārds un uzvārds ir obligāti.", "error")
        return redirect(url_for("players_edit", player_id=player_id))

    conn = get_db()
    conn.execute(
        """
        UPDATE players
        SET first_name = ?, last_name = ?, country = ?, birth_year = ?, hand = ?
        WHERE id = ?
        """,
        (first_name, last_name, country, birth_year, hand, player_id),
    )
    conn.commit()
    conn.close()
    flash("Spēlētājs atjaunots.", "success")
    return redirect(url_for("players_view", player_id=player_id))


@app.route("/players/<int:player_id>/delete", methods=["POST"])
def players_delete(player_id):
    conn = get_db()
    try:
        conn.execute("DELETE FROM players WHERE id = ?", (player_id,))
        conn.commit()
        flash("Spēlētājs dzēsts.", "success")
    except sqlite3.IntegrityError:
        flash("Šo spēlētāju nevar dzēst, jo viņš ir piesaistīts mačiem.", "error")
    conn.close()
    return redirect(url_for("players_list"))


# ---------- Turnīri ----------

@app.route("/tournaments")
def tournaments_list():
    conn = get_db()
    tournaments = conn.execute(
        "SELECT id, name, level, location, surface FROM tournaments ORDER BY name"
    ).fetchall()
    conn.close()
    return render_template("tournaments/list.html", tournaments=tournaments)


@app.route("/tournaments/new")
def tournaments_new():
    return render_template("tournaments/new.html")


@app.route("/tournaments", methods=["POST"])
def tournaments_create():
    name = request.form.get("name", "").strip()
    level = request.form.get("level", "").strip() or None
    location = request.form.get("location", "").strip() or None
    surface = request.form.get("surface", "").strip() or None

    if not name:
        flash("Turnīra nosaukums ir obligāts.", "error")
        return render_template("tournaments/new.html", form=request.form)

    conn = get_db()
    conn.execute(
        """
        INSERT INTO tournaments (name, level, location, surface)
        VALUES (?, ?, ?, ?)
        """,
        (name, level, location, surface),
    )
    conn.commit()
    conn.close()
    flash("Turnīrs pievienots.", "success")
    return redirect(url_for("tournaments_list"))


@app.route("/tournaments/<int:tournament_id>")
def tournaments_view(tournament_id):
    conn = get_db()
    tournament = conn.execute(
        "SELECT * FROM tournaments WHERE id = ?", (tournament_id,)
    ).fetchone()
    if tournament is None:
        conn.close()
        abort(404)

    matches = conn.execute(
        """
        SELECT m.id, m.match_date, m.round, m.score,
               wp.first_name AS winner_first, wp.last_name AS winner_last,
               lp.first_name AS loser_first, lp.last_name AS loser_last
        FROM matches m
        JOIN players wp ON wp.id = m.winner_player_id
        JOIN players lp ON lp.id = m.loser_player_id
        WHERE m.tournament_id = ?
        ORDER BY m.match_date DESC
        """,
        (tournament_id,),
    ).fetchall()
    conn.close()
    return render_template("tournaments/view.html", tournament=tournament, matches=matches)


@app.route("/tournaments/<int:tournament_id>/edit")
def tournaments_edit(tournament_id):
    conn = get_db()
    tournament = conn.execute(
        "SELECT * FROM tournaments WHERE id = ?", (tournament_id,)
    ).fetchone()
    conn.close()
    if tournament is None:
        abort(404)
    return render_template("tournaments/edit.html", tournament=tournament)


@app.route("/tournaments/<int:tournament_id>", methods=["POST"])
def tournaments_update(tournament_id):
    name = request.form.get("name", "").strip()
    level = request.form.get("level", "").strip() or None
    location = request.form.get("location", "").strip() or None
    surface = request.form.get("surface", "").strip() or None

    if not name:
        flash("Turnīra nosaukums ir obligāts.", "error")
        return redirect(url_for("tournaments_edit", tournament_id=tournament_id))

    conn = get_db()
    conn.execute(
        """
        UPDATE tournaments
        SET name = ?, level = ?, location = ?, surface = ?
        WHERE id = ?
        """,
        (name, level, location, surface, tournament_id),
    )
    conn.commit()
    conn.close()
    flash("Turnīrs atjaunots.", "success")
    return redirect(url_for("tournaments_view", tournament_id=tournament_id))


@app.route("/tournaments/<int:tournament_id>/delete", methods=["POST"])
def tournaments_delete(tournament_id):
    conn = get_db()
    try:
        conn.execute("DELETE FROM tournaments WHERE id = ?", (tournament_id,))
        conn.commit()
        flash("Turnīrs dzēsts.", "success")
    except sqlite3.IntegrityError:
        flash("Šo turnīru nevar dzēst, jo tam ir piesaistīti mači.", "error")
    conn.close()
    return redirect(url_for("tournaments_list"))


# ---------- Mači ----------

@app.route("/matches")
def matches_list():
    conn = get_db()
    matches = conn.execute(
        """
        SELECT m.id, m.match_date, m.round, m.best_of, m.score,
               t.name AS tournament_name,
               wp.first_name AS winner_first, wp.last_name AS winner_last,
               lp.first_name AS loser_first, lp.last_name AS loser_last
        FROM matches m
        JOIN tournaments t ON t.id = m.tournament_id
        JOIN players wp ON wp.id = m.winner_player_id
        JOIN players lp ON lp.id = m.loser_player_id
        ORDER BY m.match_date DESC, m.id DESC
        """
    ).fetchall()
    conn.close()
    return render_template("matches/list.html", matches=matches)


@app.route("/matches/new")
def matches_new():
    players, tournaments = get_players_and_tournaments()
    return render_template("matches/new.html", players=players, tournaments=tournaments)


@app.route("/matches", methods=["POST"])
def matches_create():
    tournament_id = to_int(request.form.get("tournament_id"), 0)
    match_date = request.form.get("match_date", "").strip()
    round_name = request.form.get("round", "").strip() or None
    best_of = to_int(request.form.get("best_of"), 3)
    winner_player_id = to_int(request.form.get("winner_player_id"), 0)
    loser_player_id = to_int(request.form.get("loser_player_id"), 0)
    score = request.form.get("score", "").strip() or None

    if not tournament_id or not match_date or not winner_player_id or not loser_player_id:
        flash("Turnīrs, datums, uzvarētājs un zaudētājs ir obligāti.", "error")
        return redirect(url_for("matches_new"))

    if winner_player_id == loser_player_id:
        flash("Uzvarētājs un zaudētājs nevar būt viens un tas pats spēlētājs.", "error")
        return redirect(url_for("matches_new"))

    conn = get_db()
    conn.execute(
        """
        INSERT INTO matches (tournament_id, match_date, round, best_of, winner_player_id, loser_player_id, score)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (tournament_id, match_date, round_name, best_of, winner_player_id, loser_player_id, score),
    )
    conn.commit()
    conn.close()
    flash("Mačs pievienots.", "success")
    return redirect(url_for("matches_list"))


@app.route("/matches/<int:match_id>")
def matches_view(match_id):
    conn = get_db()
    match = conn.execute(
        """
        SELECT m.*, t.name AS tournament_name, t.surface AS tournament_surface,
               wp.first_name AS winner_first, wp.last_name AS winner_last,
               lp.first_name AS loser_first, lp.last_name AS loser_last
        FROM matches m
        JOIN tournaments t ON t.id = m.tournament_id
        JOIN players wp ON wp.id = m.winner_player_id
        JOIN players lp ON lp.id = m.loser_player_id
        WHERE m.id = ?
        """,
        (match_id,),
    ).fetchone()
    if match is None:
        conn.close()
        abort(404)

    stats = conn.execute(
        """
        SELECT ms.*, p.first_name, p.last_name
        FROM match_stats ms
        JOIN players p ON p.id = ms.player_id
        WHERE ms.match_id = ?
        ORDER BY p.last_name, p.first_name
        """,
        (match_id,),
    ).fetchall()
    conn.close()
    return render_template("matches/view.html", match=match, stats=stats)


@app.route("/matches/<int:match_id>/edit")
def matches_edit(match_id):
    conn = get_db()
    match = conn.execute("SELECT * FROM matches WHERE id = ?", (match_id,)).fetchone()
    conn.close()
    if match is None:
        abort(404)

    players, tournaments = get_players_and_tournaments()
    return render_template("matches/edit.html", match=match, players=players, tournaments=tournaments)


@app.route("/matches/<int:match_id>", methods=["POST"])
def matches_update(match_id):
    tournament_id = to_int(request.form.get("tournament_id"), 0)
    match_date = request.form.get("match_date", "").strip()
    round_name = request.form.get("round", "").strip() or None
    best_of = to_int(request.form.get("best_of"), 3)
    winner_player_id = to_int(request.form.get("winner_player_id"), 0)
    loser_player_id = to_int(request.form.get("loser_player_id"), 0)
    score = request.form.get("score", "").strip() or None

    if winner_player_id == loser_player_id:
        flash("Uzvarētājs un zaudētājs nevar būt viens un tas pats spēlētājs.", "error")
        return redirect(url_for("matches_edit", match_id=match_id))

    conn = get_db()
    conn.execute(
        """
        UPDATE matches
        SET tournament_id = ?, match_date = ?, round = ?, best_of = ?,
            winner_player_id = ?, loser_player_id = ?, score = ?
        WHERE id = ?
        """,
        (tournament_id, match_date, round_name, best_of, winner_player_id, loser_player_id, score, match_id),
    )
    conn.commit()
    conn.close()
    flash("Mačs atjaunots.", "success")
    return redirect(url_for("matches_view", match_id=match_id))


@app.route("/matches/<int:match_id>/delete", methods=["POST"])
def matches_delete(match_id):
    conn = get_db()
    conn.execute("DELETE FROM matches WHERE id = ?", (match_id,))
    conn.commit()
    conn.close()
    flash("Mačs dzēsts. Tam piesaistītā statistika arī tika dzēsta.", "success")
    return redirect(url_for("matches_list"))


# ---------- Maču statistika ----------

@app.route("/match-stats")
def match_stats_list():
    conn = get_db()
    stats = conn.execute(
        """
        SELECT ms.*, m.match_date, t.name AS tournament_name, p.first_name, p.last_name
        FROM match_stats ms
        JOIN matches m ON m.id = ms.match_id
        JOIN tournaments t ON t.id = m.tournament_id
        JOIN players p ON p.id = ms.player_id
        ORDER BY m.match_date DESC, ms.id DESC
        """
    ).fetchall()
    conn.close()
    return render_template("match_stats/list.html", stats=stats)


@app.route("/match-stats/new")
def match_stats_new():
    conn = get_db()
    matches = conn.execute(
        """
        SELECT m.id, m.match_date, t.name AS tournament_name,
               wp.last_name AS winner_last, lp.last_name AS loser_last
        FROM matches m
        JOIN tournaments t ON t.id = m.tournament_id
        JOIN players wp ON wp.id = m.winner_player_id
        JOIN players lp ON lp.id = m.loser_player_id
        ORDER BY m.match_date DESC
        """
    ).fetchall()
    players = conn.execute(
        "SELECT id, first_name, last_name FROM players ORDER BY last_name, first_name"
    ).fetchall()
    conn.close()
    return render_template("match_stats/new.html", matches=matches, players=players)


@app.route("/match-stats", methods=["POST"])
def match_stats_create():
    match_id = to_int(request.form.get("match_id"), 0)
    player_id = to_int(request.form.get("player_id"), 0)

    if not match_id or not player_id:
        flash("Mačs un spēlētājs ir obligāti.", "error")
        return redirect(url_for("match_stats_new"))

    conn = get_db()
    try:
        conn.execute(
            """
            INSERT INTO match_stats (
                match_id, player_id, aces, double_faults, first_serve_in,
                first_serve_total, winners, unforced_errors,
                break_points_won, break_points_total
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                match_id,
                player_id,
                to_int(request.form.get("aces"), 0),
                to_int(request.form.get("double_faults"), 0),
                to_int(request.form.get("first_serve_in"), 0),
                to_int(request.form.get("first_serve_total"), 0),
                to_int(request.form.get("winners"), 0),
                to_int(request.form.get("unforced_errors"), 0),
                to_int(request.form.get("break_points_won"), 0),
                to_int(request.form.get("break_points_total"), 0),
            ),
        )
        conn.commit()
        flash("Statistika pievienota.", "success")
    except sqlite3.IntegrityError:
        flash("Šim spēlētājam šajā mačā statistika jau eksistē.", "error")
    conn.close()
    return redirect(url_for("match_stats_list"))


@app.route("/match-stats/<int:stat_id>")
def match_stats_view(stat_id):
    conn = get_db()
    stat = conn.execute(
        """
        SELECT ms.*, m.match_date, t.name AS tournament_name, p.first_name, p.last_name
        FROM match_stats ms
        JOIN matches m ON m.id = ms.match_id
        JOIN tournaments t ON t.id = m.tournament_id
        JOIN players p ON p.id = ms.player_id
        WHERE ms.id = ?
        """,
        (stat_id,),
    ).fetchone()
    conn.close()
    if stat is None:
        abort(404)
    return render_template("match_stats/view.html", stat=stat)


@app.route("/match-stats/<int:stat_id>/edit")
def match_stats_edit(stat_id):
    conn = get_db()
    stat = conn.execute("SELECT * FROM match_stats WHERE id = ?", (stat_id,)).fetchone()
    conn.close()
    if stat is None:
        abort(404)
    return render_template("match_stats/edit.html", stat=stat)


@app.route("/match-stats/<int:stat_id>", methods=["POST"])
def match_stats_update(stat_id):
    conn = get_db()
    conn.execute(
        """
        UPDATE match_stats
        SET aces = ?, double_faults = ?, first_serve_in = ?, first_serve_total = ?,
            winners = ?, unforced_errors = ?, break_points_won = ?, break_points_total = ?
        WHERE id = ?
        """,
        (
            to_int(request.form.get("aces"), 0),
            to_int(request.form.get("double_faults"), 0),
            to_int(request.form.get("first_serve_in"), 0),
            to_int(request.form.get("first_serve_total"), 0),
            to_int(request.form.get("winners"), 0),
            to_int(request.form.get("unforced_errors"), 0),
            to_int(request.form.get("break_points_won"), 0),
            to_int(request.form.get("break_points_total"), 0),
            stat_id,
        ),
    )
    conn.commit()
    conn.close()
    flash("Statistika atjaunota.", "success")
    return redirect(url_for("match_stats_view", stat_id=stat_id))


@app.route("/match-stats/<int:stat_id>/delete", methods=["POST"])
def match_stats_delete(stat_id):
    conn = get_db()
    conn.execute("DELETE FROM match_stats WHERE id = ?", (stat_id,))
    conn.commit()
    conn.close()
    flash("Statistika dzēsta.", "success")
    return redirect(url_for("match_stats_list"))


@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(debug=True)
